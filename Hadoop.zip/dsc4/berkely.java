import java.util.Date;
import java.util.Scanner;
import java.text.SimpleDateFormat;
import java.text.ParseException;

public class berkely {
    public static void berkelyAlgooo(String serverTime,String clientTime1, String clientTime2){
        try{
        SimpleDateFormat sdf = new SimpleDateFormat("mm:ss");
        long s = sdf.parse(serverTime).getTime();
        long t1 = sdf.parse(clientTime1).getTime();
        long t2 = sdf.parse(clientTime2).getTime();

        long st1 = t1-s;
        long st2 = t2-s;

        long avg = (st1+st2+0)/3;

        long adjserver = avg+s;
        long adj_t1 = avg-st1;
        long adj_t2 = avg-st2;

        System.out.println("Synchronized Server clock time: "+sdf.format(new Date(adjserver)));
        System.out.println("Synchronized Client1 clock time: "+sdf.format(new Date(t1+adj_t1)));
        System.out.println("Synchroinized clinet2 clock time: "+sdf.format(new Date(t2+adj_t2)));
        }catch(ParseException e){
            e.printStackTrace();
        }



    }
    public static void main(String[] args){
        Scanner sc = new Scanner(System.in);
        int numClient = 2;

        String[] clientTime = new String[numClient];
        System.out.println("Enter Server Time in MM:SS Format: ");
        String serverTime = sc.next();

        for(int i=0;i<numClient;i++){
            System.out.println("Enter Time for Client "+(i+1)+" in MM:SS Format");
            clientTime[i] = sc.next();        
        }
        berkelyAlgooo(serverTime,clientTime[0],clientTime[1]);
    }
    
}